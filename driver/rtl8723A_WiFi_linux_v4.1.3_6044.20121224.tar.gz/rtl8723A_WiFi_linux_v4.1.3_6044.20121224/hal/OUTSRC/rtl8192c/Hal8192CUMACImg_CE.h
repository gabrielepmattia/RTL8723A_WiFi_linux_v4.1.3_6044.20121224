#ifndef __INC_HAL8192CU_MAC_IMG_H
#define __INC_HAL8192CU_MAC_IMG_H

/*Created on  2011/ 6/16,  6: 8*/


// MAC reg V14 - 2011-11-23
#define Rtl8192CUMAC_2T_ArrayLength 174
extern u4Byte Rtl8192CUMAC_2T_Array[Rtl8192CUMAC_2T_ArrayLength];

#endif //__INC_HAL8192CE_FW_IMG_H

