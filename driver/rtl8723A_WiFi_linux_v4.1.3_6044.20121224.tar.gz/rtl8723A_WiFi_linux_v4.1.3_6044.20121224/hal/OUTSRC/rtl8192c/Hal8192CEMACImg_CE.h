#ifndef __INC_HAL8192CE_MAC_IMG_H
#define __INC_HAL8192CE_MAC_IMG_H

/*Created on  2011/ 6/16,  6: 8*/

#define Rtl8192CEMAC_2T_ArrayLength 174
extern u4Byte Rtl8192CEMAC_2T_Array[Rtl8192CEMAC_2T_ArrayLength];

#endif //__INC_HAL8192CE_FW_IMG_H

